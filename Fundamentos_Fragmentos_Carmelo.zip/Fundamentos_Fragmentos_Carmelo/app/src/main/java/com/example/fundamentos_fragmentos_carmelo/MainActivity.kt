package com.example.fundamentos_fragmentos_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {//sobreescritura
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //recoger los componentes visuales (3)
        //1. findViewById : una para cada componente
        //2. Viewbinding : ya están enlazados en memoria. Se usan con binding directamente
        //* fragment : View y con inflate
        //3. librerías sythetic....algunas están ya en desuso
        val producto=findViewById<TextView>(R.id.et_producto)
        val unidades=findViewById<TextView>(R.id.et_unidades)
        val precio=findViewById<TextView>(R.id.et_precio)
        val fecha=findViewById<TextView>(R.id.et_fecha)
        val boton=findViewById<Button>(R.id.btn_comprar)
        val boton_envio=findViewById<Button>(R.id.btn_enviar)
        val mensaje=findViewById<TextView>(R.id.txt_mensaje)


        boton_envio.setOnClickListener(){
            var formato=DateTimeFormatter.ofPattern("dd/MM/yyyy")
            var fecha_pedido= LocalDate.parse(fecha.text.toString(),formato)
            var fecha_entrega=fecha_pedido
           /* if(fecha_pedido.month.value==1) {
                println("el mes es ?")
                println(fecha_pedido.month.value)
                fecha_entrega=fecha_pedido.plusDays(6)
            }
            else{
                fecha_entrega=fecha_pedido.plusDays(4)
            }*/

            when(fecha_pedido.month.value){
                1,2,3->fecha_entrega=fecha_pedido.plusDays(6)
                4,5,6->fecha_entrega=fecha_pedido.plusDays(10)
                in 7..12->fecha_entrega=fecha_pedido.plusDays(1)

            }

//por defecto yyyy/MM/dd
            mensaje.text="el pedido llegará el día $fecha_entrega"
           // mensaje.text="el mes es ${fecha_pedido.month.value}"
        }

        boton.setOnClickListener(){
            //utilizar clase
            val facturacion=Facturacion()
            val total:Float=facturacion.total(unidades.text.toString().toInt(),precio.text.toString().toFloat(),producto.text.toString())
            mensaje.text="total de factura $total €"
        }
//------------------------------------------------------------------------------------------ Fundamentos de Kotlin
        var n1=7
        var n2=5

        println("Operaciones aritméticas ----------------- ")
        println("Sumando")
        println(n1+n2)

        println("Dividir")
        println(n1/n2)

        println("Modulo - resto de la división")
        println(n1%n2)

        println("Operaciones aritméticas con números ----------------")
        var numero1=7.5f //inferencia de tipos
        var numero2:Int=4
        var solucion:Int //declarar una variable
        solucion=(numero1/numero2).toInt()
        solucion=numero1.toInt()/numero2 //no tiene por qué dar el mismo resultado

        println("Dividir")
        println(numero1/numero2) //resultado sea Float
        println(solucion)

        println("Concatenación----------------")
        val saludo="hola, qué tal"
        var nombre="juan"
        println(saludo+nombre) //concatenación
        println("ejemplo de saludo $saludo $nombre") //contatenación

       saludar() //llamas a una función
        saludar("Laura") //llamas a una función con un parámetro de entrada
        var respuesta=saludar("Alberto","Sevilla")
        println(respuesta)
       // caja.text=respuesta

        //utilizar funciones definidas en otra clase
        //instanciar la nueva clase
      //  Operaciones op = new Operaciones(); //ejemplo de instanciar en Java
        var op = Operaciones() //instanciar en Kotlin *sin new
        var resultado =op.calcular(5,9)
        println("mostrando el resultado $resultado")


        println("Arrays en Kotlin --------------------------------")
        val diasSemana= arrayOf("Lunes","Martes","Miércoles","Jueves","Viernes") //array
        println("El primer día de la semana es ${diasSemana[0]}")
        for(dia in diasSemana){
            println("el día es $dia")
        }

        println("Listas en Kotlin --------------------------------")
        //Lista Inmutable
        val productos:List<String> =listOf("camisa","pantalón","sombrero")
        //lista mutable
        var temperaturas:MutableList<Float> = mutableListOf(20.5f,30.6f,21.6f)
        temperaturas.add(15.5f)
        println(temperaturas)
        for(temperatura in temperaturas){
            println("la tmeperatura de hoy es  es $temperatura")
        }

    }//cierra fun onCreate
    //funciones con el mismo nombre, pero diferentes parámetros : sobrecarga




    fun saludar(){//funciones sin parámetros de entrada ni de salida
        println("llamando a la función saludar")
    }// cierra fun saludar

    fun saludar(nombre:String){ //función con parámetros de entrada
        println("hola $nombre")
    }

    fun saludar(nombre:String,ciudad:String):String{ //función con parámetro de salida y de entrada
        return "hola $nombre, qué tal por $ciudad"
    }

}//cierra clase