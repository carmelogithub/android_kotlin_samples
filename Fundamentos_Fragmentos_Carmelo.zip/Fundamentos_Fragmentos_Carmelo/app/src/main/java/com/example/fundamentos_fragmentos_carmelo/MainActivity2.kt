package com.example.fundamentos_fragmentos_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val cajadato=findViewById<TextView>(R.id.et_dato)
        val boton_add=findViewById<Button>(R.id.button)
        val caja_mensaje=findViewById<TextView>(R.id.txt_mostrar)

        var productos:MutableList<String> = mutableListOf("primer dato")

        boton_add.setOnClickListener(){
            productos.add(cajadato.text.toString())
            caja_mensaje.text=""
            var sb:StringBuilder= StringBuilder("...")
            for(producto in productos)
            {
               sb.append(producto)
                sb.append("\n")
            }
            caja_mensaje.text=sb

        }

    }
}