package com.example.fundamentos_fragmentos_carmelo

class Facturacion {

    fun total(unidades:Int,precio:Float):Float{
        return unidades*precio

    }

    //sobrecarga
    fun total(unidades:Int,precio:Float,producto:String):Float{
        var descuento=0.1f//declaración de variable e inicialización
        //if(producto=="camisa")//operador de comparación
        if(producto.equals("camisa",true))//compareTo
            descuento=0.2f//asignación
        return unidades*precio*(1-descuento)

    }

}