package com.example.fundamentos_fragmentos_carmelo

class Operaciones {

    //atributos, campos, propiedades

    //constructor

    //métodos o funciones
    fun calcular(numero1:Int, numero2:Int):Int{
        return numero1*numero2
    }

}