package com.example.productos_sqlite_carmelo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.productos_sqlite_carmelo.service.DataHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn=findViewById<FloatingActionButton>(R.id.floatingActionButton)
        val rv=findViewById<RecyclerView>(R.id.rv_productos)

        var dh= DataHelper(this)
        println("los datos son "+dh.getAllProducto().toArray()[0].toString())
        var listado=dh.getAllProducto()
        var ProductoAdaptador=ProductoAdapter(this@MainActivity,listado)
        rv.apply {
            adapter=ProductoAdaptador
            layoutManager = LinearLayoutManager(this@MainActivity)
        }

        btn.setOnClickListener(){
            val intento=Intent(this,Activity_insert::class.java)
            startActivity(intento)
        }

    }
}