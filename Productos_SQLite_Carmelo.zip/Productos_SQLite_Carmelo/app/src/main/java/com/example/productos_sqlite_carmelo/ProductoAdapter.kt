package com.example.productos_sqlite_carmelo

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.productos_sqlite_carmelo.model.Producto
//import kotlinx.android.synthetic.main.itemproducto.view.*

class ProductoAdapter(private val context:Context,var listadoproductos:ArrayList<Producto> = ArrayList()) : RecyclerView.Adapter<ProductoAdapter.ViewHolder>() {
    //cierra class
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_producto, parent, false)
        )
    }//cierra onCreateViewHolder

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.onBind(listadoproductos[position])
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        fun onBind(producto: Producto){
            itemView.findViewById<TextView>(R.id.tv_codigo).text=producto.codigo.toString()
            itemView.findViewById<TextView>(R.id.tv_nombre).text=producto.nombre.toString()
            itemView.findViewById<TextView>(R.id.tv_unidades).text=producto.unidades.toString()
            itemView.findViewById<TextView>(R.id.tv_precio).text=producto.precio.toString()
           // itemView.findViewById<ImageView>(R.id.iv_foto).


        }
    }

}//cierra clase adapter

