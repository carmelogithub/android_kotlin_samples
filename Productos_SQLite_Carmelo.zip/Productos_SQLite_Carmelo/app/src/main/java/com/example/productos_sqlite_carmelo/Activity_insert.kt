package com.example.productos_sqlite_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.productos_sqlite_carmelo.model.Producto
import com.example.productos_sqlite_carmelo.service.DataHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton

class Activity_insert : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insert)

        val codigo=findViewById<TextView>(R.id.et_codigo)
        val nombre=findViewById<TextView>(R.id.et_nombre)
        val unidades=findViewById<TextView>(R.id.et_unidades)
        val foto = findViewById<TextView>(R.id.et_foto)
        val precio = findViewById<TextView>(R.id.et_precio)
        val btn_addProducto=findViewById<Button>(R.id.btn_insertar)

        val dh=DataHelper(this)


        btn_addProducto.setOnClickListener(){

            var c:Int=codigo.text.toString().toInt()
            var n:String=nombre.text.toString()
            var u:Int=unidades.text.toString().toInt()
            var f:String=foto.text.toString()
            var p:Float=precio.text.toString().toFloat()

            dh.addProducto(Producto(c,n,u,f,p))
            Toast.makeText(this,"Producto añadido",Toast.LENGTH_LONG).show()
        }
    }
}