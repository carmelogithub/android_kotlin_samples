package com.example.productos_sqlite_carmelo.model

data class Producto(
    var codigo:Int=0,
    var nombre:String="",
    var unidades:Int=0,
    var foto:String="",
    var precio:Float=0.0f
)
