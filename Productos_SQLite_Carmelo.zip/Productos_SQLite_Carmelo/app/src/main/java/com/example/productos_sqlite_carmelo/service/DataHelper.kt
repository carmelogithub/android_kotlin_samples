package com.example.productos_sqlite_carmelo.service

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.productos_sqlite_carmelo.model.Producto

class DataHelper(private val context:Context) : SQLiteOpenHelper(context,"tienda.db",null,1){
    //cierra clase
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("create table productos ('codigo' integer primary key,'nombre' text,'unidades' integer,'foto' text,'precio' real)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun addProducto(producto:Producto):Long{
        var db=this.writableDatabase
        var contenido=ContentValues()
        contenido.put("codigo",producto.codigo)
        contenido.put("nombre",producto.nombre)
        contenido.put("unidades",producto.unidades)
        contenido.put("foto",producto.foto)
        contenido.put("precio",producto.precio)
        var insertado=db.insert("productos",null,contenido)

        return insertado
    }

    fun getAllProducto():ArrayList<Producto>{
        var db=this.writableDatabase
        var listaProductos:ArrayList<Producto>  =ArrayList()
        var producto:Producto=Producto()
        var cursor=db.rawQuery("select * from productos",null)
        while (cursor.moveToNext()){
            producto.codigo=cursor.getInt(0)
            producto.nombre=cursor.getString(1)
            producto.unidades=cursor.getInt(2)
            producto.foto=cursor.getString(3)
            producto.precio=cursor.getFloat(4)

            listaProductos.add(producto)
        }
        return listaProductos
    }

}