package com.example.fragmentos_pasodatos_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //crear objeto de tipo Fragment_1
        val fragment1 = Fragment_1()//instaciar clase Fragment_1 *no lleva new en Kotlin
       // val fragment2 = Fragment_2()
        //carga el fragmento en la actividad
        supportFragmentManager.beginTransaction().replace(R.id.content_id,fragment1).commit()

    }

    fun cambiarFragment(){
        val fragment2 = Fragment_2()
        //supportFragmentManager.beginTransaction().replace(R.id.content_id,fragment2).commit()

        val bundle = Bundle()
        bundle.putString("mensaje", "un mensaje de ejemplo")

        val transaction = this.supportFragmentManager.beginTransaction()

        fragment2.arguments = bundle

        transaction.replace(R.id.content_id, fragment2)
        transaction.addToBackStack(null)
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
        transaction.commit()

    }//cierra funcion cambiarFragment
}