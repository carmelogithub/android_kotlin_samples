package com.example.tiposdeactividades_carmelo

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val boton1:Button=findViewById(R.id.btn_bottom_bar)
        boton1.setOnClickListener(){
            val intento=Intent(this,MainActivity2::class.java)
            startActivity(intento)
        }

        val boton2:Button=findViewById(R.id.btn_tabbed)
        boton2.setOnClickListener(){
            val intento=Intent(this,MainActivity3::class.java)
            startActivity(intento)
        }

        val boton3:Button=findViewById(R.id.btn_drawer)
        boton3.setOnClickListener(){
            val intento=Intent(this,MainActivity4::class.java)
            startActivity(intento)
        }

        val boton4:Button=findViewById(R.id.btn_llamada)
        boton4.setOnClickListener(){
            val intento=Intent(Intent.ACTION_DIAL)
            startActivity(intento)
        }

        val boton5:Button=findViewById(R.id.btn_web)
        boton5.setOnClickListener(){
            val web:Uri=Uri.parse("https://www.android.com")
            val intento=Intent(Intent.ACTION_VIEW,web)
            startActivity(intento)
        }

    }
}