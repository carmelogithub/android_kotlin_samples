package com.example.session_sharedpreferences_carmelo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    //variables de clase, globales...
    private lateinit var correoEt:EditText //declarar la variable
    private lateinit var passwordEt:EditText
    private lateinit var loginBtn:Button

    //almancenar la info del usuario
    private lateinit var sp:SharedPreferences

    var correo="" //inicializar es asignar el valor la primera vez
    var pass=""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        correoEt=findViewById(R.id.et_correo)
        passwordEt=findViewById(R.id.et_password)
        loginBtn=findViewById(R.id.btn_login)

        sp=getSharedPreferences("preferencias", Context.MODE_PRIVATE)

        correo=sp.getString("key_correo","").toString()
        pass=sp.getString("key_password","").toString()

        loginBtn.setOnClickListener(){
            val editor:SharedPreferences.Editor=sp.edit()
            editor.putString("key_correo",correoEt.text.toString())
            editor.putString("key_password",passwordEt.text.toString())
            editor.apply()
            //if((correoEt.text.toString().equals("admin@admin.es") || correoEt.text.toString().equals("admin@admin.com")) && passwordEt.text.toString().equals("123456")) {
            if((sp.getString("key_correo","").toString().equals("admin@admin.es") || sp.getString("key_correo","").toString().equals("admin@admin.com")) && sp.getString("key_password","").toString().equals("123456")) {
                val intent: Intent = Intent(this@MainActivity, MainActivity2::class.java)
                startActivity(intent)
                finish()
            }
            else{
                Toast.makeText(this,"login no válido",Toast.LENGTH_LONG).show()
            }

        }//cierra botón


    }//cierra onCreate
    fun saludar(){

    }
}//cierra class