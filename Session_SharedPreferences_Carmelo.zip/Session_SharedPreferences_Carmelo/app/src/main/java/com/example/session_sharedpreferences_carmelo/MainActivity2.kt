package com.example.session_sharedpreferences_carmelo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    lateinit var usuarioTv:TextView
    lateinit var contraseñaTv:TextView
    lateinit var botonLogout:Button

    lateinit var sp:SharedPreferences

    var correo=""
    var password=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        usuarioTv=findViewById(R.id.tv_userName)
        contraseñaTv=findViewById(R.id.tv_pass)
        botonLogout=findViewById(R.id.btn_logout)
        sp=getSharedPreferences("preferencias",Context.MODE_PRIVATE)
        correo=sp.getString("key_correo",null)!!
        password=sp.getString("key_password",null)!!
        usuarioTv.setText("Bienvenido, $correo")
        contraseñaTv.setText("la clave es $password")

        botonLogout.setOnClickListener(){
            val editor:SharedPreferences.Editor=sp.edit();
            editor.clear()
            editor.apply()

            val intent =Intent(this@MainActivity2,MainActivity::class.java)
            startActivity(intent)
            finish()

        }

    }//cierra onCreate
}//cierra class