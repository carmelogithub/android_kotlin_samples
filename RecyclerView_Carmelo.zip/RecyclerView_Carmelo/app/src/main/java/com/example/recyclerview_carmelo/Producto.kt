package com.example.recyclerview_carmelo

data class Producto(
    val id:Int,
    val nombre:String,
    val categoria:String,
    val precio:Float

)
{
    companion object{
        val data
        get() = listOf<Producto>(
            Producto(1,"camisa","ropa",20.95f),
            Producto(2,"ordenador","informática",220.95f),
            Producto(3,"chaqueta","ropa",30.95f)

        );
    }

}
