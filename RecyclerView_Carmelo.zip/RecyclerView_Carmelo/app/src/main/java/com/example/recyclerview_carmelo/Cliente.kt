package com.example.recyclerview_carmelo

data class Cliente(
    val id:Int,
    val nombre:String,
    val ciudad:String,
    val facturacion:Float

)//cierra Model - data Class
{ //iniciamos DTO : data transform object . serializable
    companion object {
        val data
        get()= listOf<Cliente>(

            Cliente(1,"juan","madrid",1250.95f),
            Cliente(2,"maría","sevilla",147.95f),
            Cliente(3,"laura","burgos",950.95f),
            Cliente(4,"olga","granada",1250.95f),
            Cliente(5,"pedro","murcia",145.95f),
            Cliente(6,"fernando","valencia",963.95f),
            Cliente(7,"jose","madrid",852.95f)



        )//cierra lista
    }//cierra companion object
}
