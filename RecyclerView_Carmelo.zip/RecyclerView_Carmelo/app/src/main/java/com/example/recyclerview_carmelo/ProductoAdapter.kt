package com.example.recyclerview_carmelo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView


class ProductoAdapter(private val onClick:(Producto)->Unit):
    ListAdapter<Producto, ProductoAdapter.ProductoViewHolder>(ProductoDiffCallback()) {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ProductoViewHolder {
        val view=LayoutInflater
            .from(parent.context)
            .inflate(R.layout.layout_productos_item,parent,false)
    return ProductoViewHolder(view,onClick)
    }

    override fun onBindViewHolder(holder: ProductoAdapter.ProductoViewHolder, position: Int) {
        val producto=getItem(position)
        holder.bind(producto)
    }

    class ProductoViewHolder(view: View, val onClick: (Producto) -> Unit) :RecyclerView.ViewHolder(view){

        private val nombre:TextView=view.findViewById<TextView>(R.id.textView_nombre)
        private val categoria:TextView=view.findViewById(R.id.textView2_categoria)
        private val precio:TextView=view.findViewById(R.id.textView3_precio)
        private var currentProducto:Producto? =null
        init {
        view.setOnClickListener(){
            currentProducto?.let{
            onClick(it)
            }//cierra let
        }//cierra listener
        }//cierra init
        fun bind(producto:Producto){
            currentProducto=producto
            nombre.text=producto.nombre.toString()
            categoria.text=producto.categoria.toString()
            precio.text=producto.precio.toString()
        }

    }//cierra clas

    //creamos la clase ClienteViewHolder




}

class ProductoDiffCallback:DiffUtil.ItemCallback<Producto>() {
    override fun areItemsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        return oldItem.id==newItem.id
    }

    override fun areContentsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        return oldItem==newItem
    }

}
