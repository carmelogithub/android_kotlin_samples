package com.example.recyclerview_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    //recoger RecyclerView
        val productoList:RecyclerView = findViewById(R.id.rv_productos)
        val producto_adapter= ProductoAdapter { producto:Producto-> onProductoClick(producto)}

        val gridLayoutManager = GridLayoutManager(this@MainActivity, 2)

        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) = when (position) {
                0 -> 2
                else -> 1
            }
        }

        productoList.apply {
            adapter=producto_adapter
            layoutManager=gridLayoutManager
        }

producto_adapter.submitList(Producto.data)

    }//cierra onCrete

    private fun onProductoClick(producto: Producto) {
Toast.makeText(this,"prducto pulsado",Toast.LENGTH_LONG).show()
    }//cierra funcion onClienteClick
}//cierra class