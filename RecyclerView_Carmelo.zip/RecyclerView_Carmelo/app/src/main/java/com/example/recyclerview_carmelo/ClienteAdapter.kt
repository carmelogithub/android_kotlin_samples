package com.example.recyclerview_carmelo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView


class ClienteAdapter(private val onClick:(Cliente)->Unit):
    ListAdapter<Cliente, ClienteAdapter.ClienteViewHolder>(ClienteDiffCallback()) {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ClienteViewHolder {
        val view=LayoutInflater
            .from(parent.context)
            .inflate(R.layout.layout_clientes_item,parent,false)
    return ClienteViewHolder(view,onClick)
    }

    override fun onBindViewHolder(holder: ClienteAdapter.ClienteViewHolder, position: Int) {
        val cliente=getItem(position)
        holder.bind(cliente)
    }

    class ClienteViewHolder(view: View, val onClick: (Cliente) -> Unit) :RecyclerView.ViewHolder(view){

        private val nombre:TextView=view.findViewById<TextView>(R.id.textView_nombre)
        private val ciudad:TextView=view.findViewById(R.id.textView2_ciudad)
        private val facturacion:TextView=view.findViewById(R.id.textView3_facturacion)
        private var currentCliente:Cliente? =null
        init {
        view.setOnClickListener(){
            currentCliente?.let{
            onClick(it)
            }//cierra let
        }//cierra listener
        }//cierra init
        fun bind(cliente:Cliente){
            currentCliente=cliente
            nombre.text=cliente.nombre.toString()
            ciudad.text=cliente.ciudad.toString()
            facturacion.text=cliente.facturacion.toString()
        }

    }//cierra clas

    //creamos la clase ClienteViewHolder




}

class ClienteDiffCallback:DiffUtil.ItemCallback<Cliente>() {
    override fun areItemsTheSame(oldItem: Cliente, newItem: Cliente): Boolean {
        return oldItem.id==newItem.id
    }

    override fun areContentsTheSame(oldItem: Cliente, newItem: Cliente): Boolean {
        return oldItem==newItem
    }

}
