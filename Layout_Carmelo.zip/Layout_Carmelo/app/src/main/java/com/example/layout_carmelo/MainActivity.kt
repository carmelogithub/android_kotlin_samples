package com.example.layout_carmelo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val boton=findViewById<Button>(R.id.btn_relative)
        val botonWeb=findViewById<Button>(R.id.btn_webView)
        val botonGrid=findViewById<Button>(R.id.btn_grid)
        val botonFrame=findViewById<Button>(R.id.btn_frame)

        boton.setOnClickListener(){
            //intent para pasar a la siguiente actividad
            val intent=Intent(this,MainActivityRelative::class.java)
            startActivity(intent)
        }

        botonWeb.setOnClickListener(){
            //intent para pasar a la siguiente actividad
            val intent=Intent(this,MainActivityWebView::class.java)
            startActivity(intent)
        }

        botonGrid.setOnClickListener(){
            //intent para pasar a la siguiente actividad
            val intent=Intent(this,MainActivityGrid::class.java)
            startActivity(intent)
        }

        botonFrame.setOnClickListener(){
            //intent para pasar a la siguiente actividad
            val intent=Intent(this,MainActivityFrame::class.java)
            startActivity(intent)
        }

    }
}