package com.example.layout_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class MainActivityWebView : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_web_view)

        val web:WebView = findViewById(R.id.webView1)
        web.loadUrl("https://www.xataka.com/")

    }
}