package com.example.gestionarfragments_practica_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val boton1=findViewById<Button>(R.id.button1)
        val boton2=findViewById<Button>(R.id.button2)
        val boton3=findViewById<Button>(R.id.button3)

        boton1.setOnClickListener(){
            val fragment1=Fragment1()
            supportFragmentManager.beginTransaction().replace(R.id.content_id,fragment1).commit()
        }

        boton2.setOnClickListener(){
            pasarFragment2()
        }

        boton3.setOnClickListener(){
            val fragment3=Fragment3()
            supportFragmentManager.beginTransaction().replace(R.id.content_id,fragment3).commit()
        }//cierra onclick button
    }//cierra onCreate
    fun pasarFragment2(){
        val fragment2=Fragment2()
        supportFragmentManager.beginTransaction().replace(R.id.content_id,fragment2).commit()
    }
}