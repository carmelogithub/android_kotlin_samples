package com.example.intents_layout_carmelo

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var boton:Button=findViewById(R.id.button)
        boton.setOnClickListener(){
            val intento=Intent(this,MainActivity2::class.java)
            startActivity(intento)
        }

        var boton4:Button=findViewById(R.id.button4)
        boton4.setOnClickListener(){
            val intento=Intent(this,MainActivity3::class.java)
            startActivity(intento)
        }


        var boton2:Button=findViewById(R.id.button2)
        boton2.setOnClickListener(){
            val intentoCamara=Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivity(intentoCamara)
        }

        var boton3:Button=findViewById(R.id.button3)
        boton3.setOnClickListener(){
            val rutaWeb:Uri=Uri.parse("https://www.google.com")
            val intentoWeb=Intent(Intent.ACTION_VIEW,rutaWeb)
            startActivity(intentoWeb)
        }

    }
}