package com.example.recyclerview_adapter_arraylist_carmelo

data class ItemModel(val Image:Int,val texto: String)
