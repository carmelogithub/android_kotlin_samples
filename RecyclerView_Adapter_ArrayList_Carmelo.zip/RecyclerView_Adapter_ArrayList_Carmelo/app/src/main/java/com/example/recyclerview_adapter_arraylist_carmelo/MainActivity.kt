package com.example.recyclerview_adapter_arraylist_carmelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler=findViewById<RecyclerView>(R.id.rv)
        recycler.layoutManager=LinearLayoutManager(this)

        val data=ArrayList<ItemModel>()

        for (i in 1..10){
            data.add(ItemModel(androidx.appcompat.R.drawable.abc_ic_arrow_drop_right_black_24dp,"Elemento "+i))
        }
        val adaptador=ItemAdapter(data)
        recycler.adapter=adaptador

    }
}